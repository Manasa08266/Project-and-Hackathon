// ── DATA STORE ────────────────────────────────────────────────
const DB = {
  vessels: [
    { id: 'V001', name: 'MSC Meridian', type: 'Container', flag: '🇸🇬', captain: 'Capt. Chen Wei', berth: 'A-12', status: 'Docked', eta: '2025-07-14', cargo: 'Electronics', weight: '18,400 MT', containers: 842 },
    { id: 'V002', name: 'Pacific Eagle', type: 'Bulk Carrier', flag: '🇯🇵', captain: 'Capt. Tanaka', berth: 'B-07', status: 'Loading', eta: '2025-07-15', cargo: 'Coal', weight: '52,000 MT', containers: 0 },
    { id: 'V003', name: 'Nordic Star', type: 'Tanker', flag: '🇳🇴', captain: 'Capt. Hansen', berth: 'C-03', status: 'Unloading', eta: '2025-07-13', cargo: 'Crude Oil', weight: '80,000 MT', containers: 0 },
    { id: 'V004', name: 'Arabian Prince', type: 'Container', flag: '🇦🇪', captain: 'Capt. Al Rashid', berth: '—', status: 'Incoming', eta: '2025-07-16', cargo: 'General', weight: '22,100 MT', containers: 1024 },
    { id: 'V005', name: 'Blue Horizon', type: 'RoRo', flag: '🇩🇪', captain: 'Capt. Müller', berth: 'D-01', status: 'Docked', eta: '2025-07-12', cargo: 'Vehicles', weight: '9,800 MT', containers: 0 },
    { id: 'V006', name: 'Coral Sea', type: 'Container', flag: '🇦🇺', captain: 'Capt. James', berth: 'A-08', status: 'Departing', eta: '2025-07-14', cargo: 'Mixed', weight: '14,500 MT', containers: 610 },
    { id: 'V007', name: 'Iron Fortune', type: 'Bulk Carrier', flag: '🇨🇳', captain: 'Capt. Li Ming', berth: '—', status: 'Incoming', eta: '2025-07-17', cargo: 'Iron Ore', weight: '68,000 MT', containers: 0 },
    { id: 'V008', name: 'Gulf Breeze', type: 'Tanker', flag: '🇸🇦', captain: 'Capt. Hassan', berth: 'C-06', status: 'Maintenance', eta: '2025-07-20', cargo: 'LNG', weight: '45,000 MT', containers: 0 },
  ],

  cargo: [
    { id: 'CG001', ref: 'CGO-2025-4412', vessel: 'MSC Meridian', type: 'Electronics', weight: '4,200 MT', containers: 180, origin: 'Shanghai', destination: 'Mumbai', status: 'Unloading', hazmat: false, value: '$8.4M' },
    { id: 'CG002', ref: 'CGO-2025-4413', vessel: 'Pacific Eagle', type: 'Coal', weight: '52,000 MT', containers: 0, origin: 'Brisbane', destination: 'Chennai', status: 'Loading', hazmat: false, value: '$2.1M' },
    { id: 'CG003', ref: 'CGO-2025-4414', vessel: 'Nordic Star', type: 'Crude Oil', weight: '80,000 MT', containers: 0, origin: 'Abu Dhabi', destination: 'Chennai', status: 'Unloading', hazmat: true, value: '$44M' },
    { id: 'CG004', ref: 'CGO-2025-4415', vessel: 'Blue Horizon', type: 'Automobiles', weight: '9,800 MT', containers: 0, origin: 'Hamburg', destination: 'Kochi', status: 'Customs', hazmat: false, value: '$12.6M' },
    { id: 'CG005', ref: 'CGO-2025-4416', vessel: 'Arabian Prince', type: 'General Goods', weight: '22,100 MT', containers: 1024, origin: 'Dubai', destination: 'Visakhapatnam', status: 'In Transit', hazmat: false, value: '$6.8M' },
    { id: 'CG006', ref: 'CGO-2025-4417', vessel: 'Coral Sea', type: 'Mixed Goods', weight: '14,500 MT', containers: 610, origin: 'Sydney', destination: 'Colombo', status: 'Ready', hazmat: false, value: '$5.2M' },
    { id: 'CG007', ref: 'CGO-2025-4418', vessel: 'Iron Fortune', type: 'Iron Ore', weight: '68,000 MT', containers: 0, origin: 'Dalian', destination: 'Visakhapatnam', status: 'In Transit', hazmat: false, value: '$3.4M' },
    { id: 'CG008', ref: 'CGO-2025-4419', vessel: 'Gulf Breeze', type: 'LNG', weight: '45,000 MT', containers: 0, origin: 'Doha', destination: 'Mumbai', status: 'Delayed', hazmat: true, value: '$28M' },
  ],

  berths: [
    { id: 'A-08', zone: 'Zone A', type: 'Container', capacity: '1,200 TEU', length: '350m', status: 'Occupied', vessel: 'Coral Sea', depth: '14m' },
    { id: 'A-12', zone: 'Zone A', type: 'Container', capacity: '1,500 TEU', length: '400m', status: 'Occupied', vessel: 'MSC Meridian', depth: '16m' },
    { id: 'B-07', zone: 'Zone B', type: 'Bulk', capacity: '80,000 MT', length: '300m', status: 'Occupied', vessel: 'Pacific Eagle', depth: '12m' },
    { id: 'B-11', zone: 'Zone B', type: 'Bulk', capacity: '80,000 MT', length: '300m', status: 'Available', vessel: '—', depth: '12m' },
    { id: 'C-03', zone: 'Zone C', type: 'Tanker', capacity: '100,000 MT', length: '380m', status: 'Occupied', vessel: 'Nordic Star', depth: '18m' },
    { id: 'C-06', zone: 'Zone C', type: 'Tanker', capacity: '100,000 MT', length: '380m', status: 'Maintenance', vessel: 'Gulf Breeze', depth: '18m' },
    { id: 'D-01', zone: 'Zone D', type: 'RoRo', capacity: '2,500 Units', length: '250m', status: 'Occupied', vessel: 'Blue Horizon', depth: '10m' },
    { id: 'D-04', zone: 'Zone D', type: 'RoRo', capacity: '2,500 Units', length: '250m', status: 'Available', vessel: '—', depth: '10m' },
    { id: 'E-02', zone: 'Zone E', type: 'General', capacity: '25,000 MT', length: '220m', status: 'Available', vessel: '—', depth: '9m' },
    { id: 'E-05', zone: 'Zone E', type: 'General', capacity: '25,000 MT', length: '220m', status: 'Available', vessel: '—', depth: '9m' },
  ],

  staff: [
    { id: 'S001', name: 'Ravi Kumar', role: 'Port Master', dept: 'Operations', shift: 'Day', status: 'On Duty', contact: '+91-98765-43210' },
    { id: 'S002', name: 'Priya Sharma', role: 'Cargo Inspector', dept: 'Customs', shift: 'Day', status: 'On Duty', contact: '+91-98765-43211' },
    { id: 'S003', name: 'Arjun Mehta', role: 'Crane Operator', dept: 'Logistics', shift: 'Day', status: 'On Duty', contact: '+91-98765-43212' },
    { id: 'S004', name: 'Sita Reddy', role: 'Safety Officer', dept: 'Safety', shift: 'Night', status: 'Off Duty', contact: '+91-98765-43213' },
    { id: 'S005', name: 'Vikram Nair', role: 'Dock Supervisor', dept: 'Operations', shift: 'Day', status: 'On Duty', contact: '+91-98765-43214' },
    { id: 'S006', name: 'Ananya Pillai', role: 'Customs Officer', dept: 'Customs', shift: 'Day', status: 'On Duty', contact: '+91-98765-43215' },
    { id: 'S007', name: 'Deepak Singh', role: 'Maintenance Tech', dept: 'Engineering', shift: 'Night', status: 'On Duty', contact: '+91-98765-43216' },
    { id: 'S008', name: 'Meera Iyer', role: 'Admin Manager', dept: 'Administration', shift: 'Day', status: 'On Duty', contact: '+91-98765-43217' },
  ]
};

// ── NAVIGATION ────────────────────────────────────────────────
function navigate(page) {
  document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.page-content').forEach(el => el.classList.remove('active'));
  const nav = document.querySelector(`[data-page="${page}"]`);
  const content = document.getElementById(`page-${page}`);
  if (nav) nav.classList.add('active');
  if (content) content.classList.add('active');
  const titles = {
    dashboard: ['Dashboard', 'Port Operations Overview'],
    vessels: ['Vessels', 'Fleet & Ship Management'],
    cargo: ['Cargo', 'Cargo Tracking & Manifest'],
    berths: ['Berths', 'Berth Allocation & Status'],
    staff: ['Staff', 'Personnel Management'],
    reports: ['Reports', 'Analytics & Reports'],
  };
  if (titles[page]) {
    document.getElementById('page-title').textContent = titles[page][0];
    document.getElementById('page-subtitle').textContent = titles[page][1];
  }
}

// ── CLOCK ─────────────────────────────────────────────────────
function updateClock() {
  const now = new Date();
  const t = now.toLocaleTimeString('en-IN', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const el = document.getElementById('live-clock');
  if (el) el.textContent = `IST ${t}`;
}
setInterval(updateClock, 1000);
updateClock();

// ── HELPERS ───────────────────────────────────────────────────
function statusBadge(s) {
  const map = {
    'Docked': 'badge-green', 'Loading': 'badge-blue', 'Unloading': 'badge-blue',
    'Incoming': 'badge-amber', 'Departing': 'badge-gray', 'Maintenance': 'badge-red',
    'Occupied': 'badge-blue', 'Available': 'badge-green', 'Ready': 'badge-green',
    'Customs': 'badge-amber', 'Delayed': 'badge-red', 'In Transit': 'badge-amber',
    'On Duty': 'badge-green', 'Off Duty': 'badge-gray',
  };
  return `<span class="badge ${map[s] || 'badge-gray'}">${s}</span>`;
}

function filterTable(inputId, tableBodyId) {
  const q = document.getElementById(inputId).value.toLowerCase();
  document.querySelectorAll(`#${tableBodyId} tr`).forEach(row => {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

// ── VESSELS PAGE ──────────────────────────────────────────────
function renderVessels(data) {
  const tbody = document.getElementById('vessels-tbody');
  tbody.innerHTML = data.map(v => `
    <tr>
      <td class="name-cell">${v.flag} ${v.name}</td>
      <td>${v.id}</td>
      <td>${v.type}</td>
      <td>${v.captain}</td>
      <td>${v.berth}</td>
      <td>${statusBadge(v.status)}</td>
      <td>${v.eta}</td>
      <td>${v.cargo}</td>
      <td>
        <button class="btn btn-outline btn-sm" onclick="showVesselDetail('${v.id}')">View</button>
      </td>
    </tr>
  `).join('');
}

function showVesselDetail(id) {
  const v = DB.vessels.find(x => x.id === id);
  if (!v) return;
  document.getElementById('vessel-detail-body').innerHTML = `
    <div class="two-col" style="gap:0.75rem;margin-bottom:1rem;">
      <div><div class="form-label">Vessel Name</div><div style="font-size:15px;font-weight:700">${v.flag} ${v.name}</div></div>
      <div><div class="form-label">Vessel ID</div><div style="font-family:var(--font-mono)">${v.id}</div></div>
      <div><div class="form-label">Type</div><div>${v.type}</div></div>
      <div><div class="form-label">Flag</div><div>${v.flag}</div></div>
      <div><div class="form-label">Captain</div><div>${v.captain}</div></div>
      <div><div class="form-label">Status</div>${statusBadge(v.status)}</div>
      <div><div class="form-label">Berth</div><div>${v.berth}</div></div>
      <div><div class="form-label">ETA</div><div style="font-family:var(--font-mono)">${v.eta}</div></div>
      <div><div class="form-label">Cargo Type</div><div>${v.cargo}</div></div>
      <div><div class="form-label">Gross Weight</div><div style="font-family:var(--font-mono)">${v.weight}</div></div>
      ${v.containers ? `<div><div class="form-label">Containers (TEU)</div><div style="font-family:var(--font-mono)">${v.containers}</div></div>` : ''}
    </div>
  `;
  openModal('vessel-detail-modal');
}

// ── CARGO PAGE ────────────────────────────────────────────────
function renderCargo(data) {
  const tbody = document.getElementById('cargo-tbody');
  tbody.innerHTML = data.map(c => `
    <tr>
      <td style="font-family:var(--font-mono);font-size:11px;">${c.ref}</td>
      <td class="name-cell">${c.vessel}</td>
      <td>${c.type}</td>
      <td>${c.origin} → ${c.destination}</td>
      <td>${c.weight}</td>
      <td>${statusBadge(c.status)}</td>
      <td>${c.hazmat ? '<span class="badge badge-red">⚠ HAZMAT</span>' : '<span class="badge badge-gray">Standard</span>'}</td>
      <td style="color:var(--cyan)">${c.value}</td>
    </tr>
  `).join('');
}

// ── BERTHS PAGE ───────────────────────────────────────────────
function renderBerths(data) {
  const tbody = document.getElementById('berths-tbody');
  tbody.innerHTML = data.map(b => `
    <tr>
      <td class="name-cell">${b.id}</td>
      <td>${b.zone}</td>
      <td>${b.type}</td>
      <td>${b.length}</td>
      <td>${b.depth}</td>
      <td>${b.capacity}</td>
      <td>${b.vessel}</td>
      <td>${statusBadge(b.status)}</td>
    </tr>
  `).join('');
}

// ── STAFF PAGE ────────────────────────────────────────────────
function renderStaff(data) {
  const tbody = document.getElementById('staff-tbody');
  tbody.innerHTML = data.map(s => `
    <tr>
      <td class="name-cell">${s.name}</td>
      <td>${s.id}</td>
      <td>${s.role}</td>
      <td>${s.dept}</td>
      <td><span class="badge ${s.shift === 'Day' ? 'badge-amber' : 'badge-blue'}">${s.shift}</span></td>
      <td>${statusBadge(s.status)}</td>
      <td style="font-family:var(--font-mono);font-size:11px;">${s.contact}</td>
    </tr>
  `).join('');
}

// ── DASHBOARD MINI-TABLES ─────────────────────────────────────
function renderDashboardVessels() {
  const tbody = document.getElementById('dash-vessels-tbody');
  tbody.innerHTML = DB.vessels.slice(0, 5).map(v => `
    <tr>
      <td class="name-cell">${v.flag} ${v.name}</td>
      <td>${v.type}</td>
      <td>${v.berth}</td>
      <td>${statusBadge(v.status)}</td>
    </tr>
  `).join('');
}

// ── REPORTS ───────────────────────────────────────────────────
function renderReports() {
  const byType = {};
  DB.cargo.forEach(c => { byType[c.type] = (byType[c.type] || 0) + 1; });
  const rows = Object.entries(byType).map(([t, n]) => `
    <tr>
      <td class="name-cell">${t}</td>
      <td>${n} shipment${n > 1 ? 's' : ''}</td>
      <td>${DB.cargo.filter(c => c.type === t).map(c => c.weight).join(', ')}</td>
    </tr>`).join('');
  const tbody = document.getElementById('report-cargo-tbody');
  if (tbody) tbody.innerHTML = rows;
}

// ── ADD VESSEL FORM ────────────────────────────────────────────
function addVessel(e) {
  e.preventDefault();
  const name = document.getElementById('new-vessel-name').value.trim();
  const type = document.getElementById('new-vessel-type').value;
  const captain = document.getElementById('new-vessel-captain').value.trim();
  const cargo = document.getElementById('new-vessel-cargo').value.trim();
  const eta = document.getElementById('new-vessel-eta').value;
  if (!name || !type || !captain || !cargo || !eta) return alert('Please fill all fields.');
  const newV = {
    id: 'V' + String(DB.vessels.length + 1).padStart(3, '0'),
    name, type, flag: '🌐', captain, berth: '—',
    status: 'Incoming', eta, cargo, weight: 'TBD', containers: 0
  };
  DB.vessels.push(newV);
  renderVessels(DB.vessels);
  renderDashboardVessels();
  closeModal('add-vessel-modal');
  document.getElementById('add-vessel-form').reset();
  showToast(`Vessel "${name}" added successfully`);
}

// ── TOAST ─────────────────────────────────────────────────────
function showToast(msg) {
  const t = document.createElement('div');
  t.style.cssText = `position:fixed;bottom:1.5rem;right:1.5rem;background:var(--ocean);color:#fff;padding:10px 18px;border-radius:8px;font-size:13px;z-index:999;font-family:var(--font-display);font-weight:600;animation:fadeIn 0.3s ease;`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

// ── INIT ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  renderVessels(DB.vessels);
  renderCargo(DB.cargo);
  renderBerths(DB.berths);
  renderStaff(DB.staff);
  renderDashboardVessels();
  renderReports();
  navigate('dashboard');
});
