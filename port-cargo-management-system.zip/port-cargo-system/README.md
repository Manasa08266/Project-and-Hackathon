# PortOS — Port & Cargo Management System

A professional, browser-based Port and Cargo Management System built with HTML, CSS, and JavaScript.

## Features

### Dashboard
- Live port map showing berth occupancy (Zones A–E)
- Real-time IST clock
- Key stats: vessels, cargo, berths, staff
- Alerts & notifications for HAZMAT, maintenance, incoming vessels
- Berth utilisation progress bars
- Cargo value summary

### Vessels Module
- Full vessel registry (8 vessels with detailed info)
- Filter/search functionality
- Add new vessel via form modal
- View detailed vessel info in modal
- Status badges: Docked, Loading, Unloading, Incoming, Departing, Maintenance

### Cargo Module
- Cargo manifest tracking
- Origin → Destination routing
- HAZMAT flagging
- Cargo value display
- Status: Loading, Unloading, In Transit, Customs, Ready, Delayed

### Berths Module
- All 10 berths across 5 zones (A–E)
- Zone types: Container, Bulk, Tanker, RoRo, General
- Real-time status tracking

### Staff Module
- Personnel directory
- Shift management (Day/Night)
- Department grouping
- On Duty / Off Duty status

### Reports Module
- Vessel status breakdown
- Cargo status breakdown
- Cargo type summary table
- KPI cards: Throughput, Revenue, Turnaround Time

## How to Use

1. Extract the zip file
2. Open `index.html` in any modern web browser
3. Navigate between modules using the left sidebar
4. Use the search inputs to filter tables
5. Click "Add Vessel" to add a new vessel record
6. Click "View" on any vessel row to see full details

## Tech Stack

- **HTML5** — Semantic structure
- **CSS3** — Custom design with CSS variables, grid, flexbox
- **Vanilla JavaScript** — No frameworks or dependencies
- **Google Fonts** — Syne + JetBrains Mono

## Browser Support

Works in all modern browsers: Chrome, Firefox, Edge, Safari.

---
Built for Port Authority Operations Management
